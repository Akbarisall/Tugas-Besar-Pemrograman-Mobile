package com.faisal.bike24

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
