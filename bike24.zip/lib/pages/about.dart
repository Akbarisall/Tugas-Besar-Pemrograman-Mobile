import 'package:flutter/material.dart';
import '../widgets/widgets.dart'; 

class TentangAplikasiPage extends StatelessWidget {
  const TentangAplikasiPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: const CustomAppBar(title: 'Tentang'),
      backgroundColor: const Color.fromRGBO(242, 231, 213, 1), 
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: SingleChildScrollView(
          child: Container(
            padding: const EdgeInsets.all(16.0),
            decoration: BoxDecoration(
              color: const Color.fromRGBO(247, 247, 247, 1), 
              borderRadius: BorderRadius.circular(10), 
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: <Widget>[
                Image.asset('assets/images/logo.png', width: 150, height: 150),
                const SizedBox(height: 20),
                const Text(
                  'Bike24 adalah aplikasi manajemen stok sparepart sepeda yang membantu mengelola dan memantau stok barang secara efektif dan efisien.',
                  textAlign: TextAlign.center,
                  style: TextStyle(fontSize: 16),
                ),
                const SizedBox(height: 20),
                const CircleAvatar(
                  radius: 50,
                  backgroundImage:
                      AssetImage('assets/images/profile.png'), 
                ),
                const SizedBox(height: 20),
                const Text(
                  'Fikri Faisal Akbar',
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 10),
                const Text(
                  'Saya seoranga mahasiswa Teknik Informatika di Institut Teknologi Garut. Saya bersemangat mempelajari berbagai aspek komunikasi serta membangun keterampilan kepemimpinan. Saya percaya pendidikan adalah kunci masa depan dan berkomitmen untuk belajar maksimal selama kuliah.',
                  textAlign: TextAlign.center,
                  style: TextStyle(fontSize: 16),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
