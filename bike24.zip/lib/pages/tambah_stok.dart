import 'package:flutter/material.dart';
import 'package:dio/dio.dart';
import '../models/stok.dart'; 
import '../widgets/widgets.dart'; 

class TambahStokPage extends StatefulWidget {
  const TambahStokPage({super.key});

  @override
  _TambahStokPageState createState() => _TambahStokPageState();
}

class _TambahStokPageState extends State<TambahStokPage> {
  final _formKey = GlobalKey<FormState>();
  String _nama = '';
  int _Jumlah = 0;
  String _atribut = '';
  double _berat = 0.0;
  String _issuer = '';

  Future<void> _submitForm() async {
    if (_formKey.currentState!.validate()) {
      _formKey.currentState!.save();

      
      Stok stok = Stok(
        id: '', 
        name: _nama,
        qty: _Jumlah,
        attr: _atribut,
        weight: _berat,
        createdAt: DateTime.now(),
        updatedAt: DateTime.now(),
        issuer: _issuer,
      );

      
      String apiUrl = 'https://api.kartel.dev/stocks';

      try {
        
        print('Data yang dikirim: ${stok.toJson()}');

        
        var response = await Dio().post(
          apiUrl,
          data: stok.toJson(),
          options: Options(
            headers: {
              'Content-Type': 'application/json',
            },
            validateStatus: (status) {
              return status! < 500; 
            },
          ),
        );

        if (response.statusCode == 200 || response.statusCode == 201) {
          
          await showDialog(
            context: context,
            builder: (context) {
              return AlertDialog(
                title: const Text('Berhasil'),
                content: const Text('Stok berhasil ditambahkan'),
                actions: [
                  TextButton(
                    onPressed: () {
                      Navigator.pop(context); 
                      Navigator.pop(context,
                          true); 
                    },
                    child: const Text('OK'),
                  ),
                ],
              );
            },
          );
        } else {
          
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
                content:
                    Text('Gagal menambah stok: ${response.statusMessage}')),
          );
        }
      } catch (e) {
        
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Terjadi kesalahan: $e')),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: const CustomAppBar(title: 'Tambah Stok'),
      backgroundColor: const Color.fromRGBO(242, 231, 213, 1), 
      body: SingleChildScrollView(
        padding: EdgeInsets.only(
            bottom: MediaQuery.of(context).viewInsets.bottom + 16.0),
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Container(
            padding: const EdgeInsets.all(16.0),
            decoration: BoxDecoration(
              color: const Color.fromRGBO(
                  247, 247, 247, 1), 
              borderRadius: BorderRadius.circular(10), 
            ),
            child: Form(
              key: _formKey,
              child: Column(
                children: <Widget>[
                  TextFormField(
                    decoration: const InputDecoration(labelText: 'Nama'),
                    onSaved: (value) {
                      _nama = value!;
                    },
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Nama tidak boleh kosong';
                      }
                      return null;
                    },
                  ),
                  TextFormField(
                    decoration: const InputDecoration(labelText: 'Jumlah'),
                    keyboardType: TextInputType.number,
                    onSaved: (value) {
                      _Jumlah = int.parse(value!);
                    },
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Jumlah tidak boleh kosong';
                      }
                      if (int.tryParse(value) == null) {
                        return 'Jumlah harus berupa angka';
                      }
                      return null;
                    },
                  ),
                  TextFormField(
                    decoration: const InputDecoration(labelText: 'Atribut'),
                    onSaved: (value) {
                      _atribut = value!;
                    },
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Atribut tidak boleh kosong';
                      }
                      return null;
                    },
                  ),
                  TextFormField(
                    decoration: const InputDecoration(labelText: 'Berat'),
                    keyboardType:
                        const TextInputType.numberWithOptions(decimal: true),
                    onSaved: (value) {
                      _berat = double.parse(value!);
                    },
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Berat tidak boleh kosong';
                      }
                      if (double.tryParse(value) == null) {
                        return 'Berat harus berupa angka';
                      }
                      return null;
                    },
                  ),
                  TextFormField(
                    decoration: const InputDecoration(labelText: 'Penyedia'),
                    onSaved: (value) {
                      _issuer = value!;
                    },
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Penyedia tidak boleh kosong';
                      }
                      return null;
                    },
                  ),
                  const SizedBox(height: 20),
                  Container(
                    margin: const EdgeInsets.all(10),
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color.fromRGBO(
                            109, 152, 134, 1), 
                        shape: RoundedRectangleBorder(
                          borderRadius:
                              BorderRadius.circular(15), 
                        ),
                        padding: const EdgeInsets.symmetric(vertical: 20),
                      ),
                      onPressed: _submitForm,
                      child: const Padding(
                        padding: EdgeInsets.symmetric(horizontal: 7),
                        child: Text('Tambahkan',
                            style:
                                TextStyle(fontSize: 18, color: Colors.white)),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
